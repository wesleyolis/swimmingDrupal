<?php
{

		       if(arg(2)==null)
			 {
			    drupal_set_title('Meet Types');
			    setseasons_breadcrumb($breadcrumb);

			    $headers[] = array('data' => t('Abbr'), 'width' => '40px');
			    $headers[] = array('nowrap'=>'nowrap','data' => t('Description'));
			    $headers[] = array('nowrap'=>'nowrap','data' => t('Last Results in'));
			    $headers[] = array('nowrap'=>'nowrap','data' => t('Next Meet info available'));

			    $query.="Select SQL_CACHE  c.abbr,c._desc,mr.MeetR,mr.MNameR,me.MeetE,me.MNameE From ".$tm4db.".code_".$season."  as c left join (select SQL_CACHE DISTINCT m.Meet AS MeetR, m.MName as MNameR,sm.abbr   from ".$tm4db.".meet_".$season."  m inner join ".$tm4db.".meet_sanctions_".$season."  as sm on (m.Meet=sm.meet) inner join ".$tm4db.".mtevent_".$season."  e on (m.Meet=e.Meet)  where e.Meet Is not Null and  sm.c=1 and m.Start is not null and m.End is not null  group by sm.abbr order by m.end desc)";
			    $query.="  as mr on (instr(mr.abbr ,CONCAT(c.abbr,','))>0) left join ";
			    $query.="( select  SQL_CACHE DISTINCT m.Meet AS MeetE, m.MName as MNameE,sm.abbr  from ".$tm4db.".meet_".$season."  m inner join ".$tm4db.".meet_sanctions_".$season." as sm on (m.Meet=sm.meet) inner join ".$tm4db.".mtevente_".$season." e on (m.Meet=e.Meet)  where e.Meet Is not Null and  sm.c=1 and m.Start >CURDATE() and m.End is not null group by sm.abbr order by m.end asc)";
			    $query.="  as me  on (instr(me.abbr ,CONCAT(c.abbr,','))>0) Where c.TYPE=3  and( mr.MeetR is not null or me.MeetE is not null) order by abbr";
			   
			    $results = db_query($query);

			    $rows[] = array(l('ALL','meets/'.arg(1).'/ALL'),' Unofficial',null,null);
			    while($object = db_fetch_object($results))
			      if($object->abbr !=null)
				$rows[] = array(l($object->abbr,'meets/'.arg(1).'/'.$object->abbr),$object->_desc,l($object->MNameR,'meets/'.arg(1).'/events/'.$object->MeetR),l($object->MNameE,'meets/'.arg(1).'/info/'.$object->MeetE));

			    $output.= theme_table($headers, $rows,array('id'=>'hyper','class'=>'hyper'),null);

			 }
		       else
			 {
			    $confirm = variable_get('perfanal_rankcon', '');
			    $cntry = variable_get('perfanal_cntry', '');

			    drupal_set_title(((arg(2)!='ALL')?arg(2):((arg(3)!=null & $cntry !=null)?$cntry:'')).' Meets');
			    setseasons_breadcrumb(array(l('Meets Types','meets/'.arg(1))));
			    //$output.= highlight_js('meets');
			    //$output.= drupal_get_form('perfanal_meet_filters_form');

			    $headers[] = array('data' => t('Meet'), 'width' => '300px','field' => 'm.MName');
			    $headers[] = array('data' => t('Sanc'), 'width' => '20px');
			    $headers[] = array('data' => t('Start date'), 'width' => '130px','sort' => 'desc','field' => 'm.Start');
			    $headers[] = array('data' => t('End date'), 'width' => '100px');
			    $headers[] = array('data' => t('Course'), 'width' => '40px');
			    $headers[] = array('data' => t('Location'));
			    // order by m.Start DESC
			    //
			    //
			    
			       $rank_from_option = variable_get('perfanal_rank_from','y');
	     
			       $Sd = variable_get('perfanal_ranking_dd', '01');
			       $Sm = variable_get('perfanal_ranking_mm', '01');
			       $from_date = $season.'-'.$Sm.'-'.$Sd;
	
			    
			    $result = db_query("select SQL_CACHE DISTINCT IF(e.Meet Is Null,1,0) as results, m.Meet, m.MName, m.Start, m.End,m.Sanction, m.Course, m.Location  from ".$tm4db.".meet_".$season." m inner join ".$tm4db.".meet_sanctions_".$season." as sm on (m.Meet=sm.meet) left join ".$tm4db.".mtevent_".$season." e on (m.Meet=e.Meet) where m.Start is not null and m.End is not null  ".((arg(2)=='ALL')?(($confirm=='')?' ':(" and (isnull(sm.abbr) or INSTR(sm.abbr,'".$cntry.",')=0 ) ")):" and instr(sm.abbr,'".arg(2)."".(($confirm!='' & arg(3)!=null)?',':'')."')>0 ").((arg(4)=='ALL')?'':" and instr(m.Course,'".arg(4)."')>0").' '.((arg(3)==null)?'':("and (DATEDIFF(m.End,'".arg(3)."')<=-2 )".(($rank_from_option=='y')?"and (DATEDIFF(m.End,'".$from_date."')>=0 )":'')))." ".tablesort_sql($headers,((arg(3)==null || arg(2)=='ALL')?'sm.c asc,':'')));
			    
			    while ($object = db_fetch_object($result))
			      {
				 $link = (($object->results==0)?'meets/'.arg(1).'/events/'.$object->Meet:'meets/'.arg(1).'/info/'.$object->Meet);

				 $class = ($object->results==0)?' green':' red';

				 $rows[] = array('class'=>$class,'data' => array(l(t($object->MName), $link),get_sanc($object->Sanction),get_date($object->Start), get_date($object->End), $object->Course, $object->Location));
			      }
			    $output.= theme_table($headers, $rows,array('id'=>'hyper','class'=>'hyper'),null);
			 }
		    }
?>